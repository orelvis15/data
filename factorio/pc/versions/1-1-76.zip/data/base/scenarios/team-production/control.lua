local handler = require("event_handler")

local team_production = require "team_production"

handler.add_lib(team_production)
