function give_points()
  return
  {
  }
end
