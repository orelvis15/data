data:extend(
{
  {
    type = "fuel-category",
    name = "chemical"
  },
  {
    type = "fuel-category",
    name = "nuclear"
  }
}
)
