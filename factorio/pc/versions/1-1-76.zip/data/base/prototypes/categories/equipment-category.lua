data:extend(
{
  {
    type = "equipment-category",
    name = "armor"
  }
}
)
